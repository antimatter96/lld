package processing

import "lld/dunzo/models/common"

// MostServed tries to serve the most number of beverages
func MostServed(ingredients common.IngredientQuantity, bevsArray []common.Beverage, n int) []common.Beverage {

	return bevsArray
}
