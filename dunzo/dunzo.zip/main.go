package main

func main() {
	// Use the diff functions to use
}
